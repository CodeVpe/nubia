// requirejs.config({
// //	baseUrl:"../scripts/",
// 	paths:{
// 		"jquery":"../scripts/libs/jquery.min",
// 		"swiper":"../scripts/libs/swiper.min",
// 		"common":"../scripts/common",
// 		"fontscroll":"../scripts/fontscroll"
// 	}
// })

requirejs.config({
//	baseUrl:"../scripts/",
	paths:{
		"jquery":"../scripts/libs/jquery.min",
		"swiper":"../scripts/libs/swiper.min",
		"common":"../scripts/common",
		"fontscroll":"../scripts/fontscroll"
	}
})